#ifndef __ERRORHANDLING_H_
#define __ERRORHANDLING_H_
void Error(char c);
#endif