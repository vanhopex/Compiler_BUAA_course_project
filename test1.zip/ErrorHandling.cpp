#include "public.h"
#include "work2.h"
#include "work3.h"
#include "ErrorHandling.h"
void Error(char c)
{
	//int ans = gline;
	//if (s[symcur].islast) ans 
	cout << c << " " << gline << endl;
	fprintf(out, "%c %d\n", c, gline);
}